package com.example.mealmatchui.data.repository

import com.example.mealmatchui.data.model.Recipe
import com.example.mealmatchui.data.model.RecipeCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

class RecipeRepository {
    private val recipes = MutableStateFlow<List<Recipe>>(getSampleRecipes())
    private val favoriteRecipes = MutableStateFlow<Set<String>>(emptySet())

    fun getAllRecipes(): Flow<List<Recipe>> = recipes

    fun getRecipesByCategory(category: RecipeCategory): Flow<List<Recipe>> =
        recipes.map { recipeList ->
            when (category) {
                RecipeCategory.ALL -> recipeList
                else -> recipeList.filter { it.category == category.name }
            }
        }

    fun searchRecipes(query: String, ingredients: List<String>): Flow<List<Recipe>> =
        recipes.map { recipeList ->
            recipeList.filter { recipe ->
                (recipe.name.contains(query, ignoreCase = true) ||
                recipe.ingredients.any { it.contains(query, ignoreCase = true) }) &&
                (ingredients.isEmpty() || ingredients.all { ingredient ->
                    recipe.ingredients.any { it.contains(ingredient, ignoreCase = true) }
                })
            }
        }

    fun getRecipeById(id: String): Flow<Recipe?> =
        recipes.map { recipeList -> recipeList.find { it.id == id } }

    fun getFavoriteRecipes(): Flow<List<Recipe>> =
        recipes.map { recipeList ->
            recipeList.filter { it.id in favoriteRecipes.value }
        }

    fun toggleFavorite(recipeId: String) {
        favoriteRecipes.update { currentFavorites ->
            if (recipeId in currentFavorites) {
                currentFavorites - recipeId
            } else {
                currentFavorites + recipeId
            }
        }
        
        recipes.update { currentRecipes ->
            currentRecipes.map { recipe ->
                if (recipe.id == recipeId) {
                    recipe.copy(isFavorite = !recipe.isFavorite)
                } else {
                    recipe
                }
            }
        }
    }

    private fun getSampleRecipes(): List<Recipe> = listOf(
        Recipe(
            id = "1",
            name = "Köfte",
            category = RecipeCategory.MEAT.name,
            ingredients = listOf(
                "500g kıyma",
                "1 adet soğan",
                "2 diş sarımsak",
                "1 yumurta",
                "Maydanoz",
                "Tuz, karabiber"
            ),
            instructions = listOf(
                "Kıymayı geniş bir kaba alın",
                "Soğan ve sarımsağı ince ince doğrayın",
                "Tüm malzemeleri karıştırın",
                "Köfte şekli verin",
                "Izgara veya tavada pişirin"
            )
        ),
        Recipe(
            id = "2",
            name = "Mercimek Çorbası",
            category = RecipeCategory.VEGETABLE.name,
            ingredients = listOf(
                "1 su bardağı kırmızı mercimek",
                "1 adet soğan",
                "1 adet havuç",
                "2 yemek kaşığı un",
                "Sıvı yağ",
                "Tuz"
            ),
            instructions = listOf(
                "Mercimeği yıkayın",
                "Sebzeleri doğrayın",
                "Tencerede soğanları kavurun",
                "Diğer malzemeleri ekleyin",
                "Mercimekler yumuşayana kadar pişirin"
            )
        ),
        Recipe(
            id = "3",
            name = "Vegan Burger",
            category = RecipeCategory.VEGAN.name,
            ingredients = listOf(
                "1 kutu nohut",
                "1 adet pancar",
                "1 adet soğan",
                "Maydanoz",
                "Baharatlar"
            ),
            instructions = listOf(
                "Nohutları ezin",
                "Sebzeleri rendeleyin",
                "Malzemeleri karıştırın",
                "Köfte şekli verin",
                "Tavada pişirin"
            )
        ),
        Recipe(
            id = "4",
            name = "Çikolatalı Kek",
            category = RecipeCategory.DESSERT.name,
            ingredients = listOf(
                "3 yumurta",
                "1.5 su bardağı şeker",
                "1.5 su bardağı un",
                "1 paket kakao",
                "1 paket kabartma tozu"
            ),
            instructions = listOf(
                "Yumurta ve şekeri çırpın",
                "Kuru malzemeleri ekleyin",
                "Karışımı kalıba dökün",
                "180 derecede 30 dakika pişirin"
            )
        )
    )
} 